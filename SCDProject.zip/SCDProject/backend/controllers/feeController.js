const db = require('../config/db');
// Fee submission (with concurrency handling)
const submitFee = async (req, res) => {
  const { student_id, amount } = req.body;
  try {
    // Start a transaction
    const connection = await db.getConnection();
    await connection.beginTransaction();

    // Check if the student has already paid
    const [existingFee] = await connection.execute('SELECT * FROM fees WHERE student_id = ? AND paid = TRUE', [student_id]);

    if (existingFee.length > 0) {
      await connection.rollback(); // Rollback if already paid
      return res.status(400).json({ message: 'Fee already paid for this student' });
    }
    // Insert the fee payment
    await connection.execute('INSERT INTO fees (student_id, amount, paid) VALUES (?, ?, ?)', [student_id, amount, true]);
    // Commit the transaction
    await connection.commit();
    res.status(200).json({ message: 'Fee paid successfully' });
  } catch (error) {
    console.error(error);
    await connection.rollback(); // Rollback on error
    res.status(500).json({ message: 'Failed to submit fee' });
  }
};
// Generate report (while payments are ongoing)
const generateReport = async (req, res) => {
  try {
    const [report] = await db.execute('SELECT student_id, amount, paid, payment_date FROM fees');
    res.status(200).json(report);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Failed to generate report' });
  }
};

module.exports = { submitFee, generateReport };
