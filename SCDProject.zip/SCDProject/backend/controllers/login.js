const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const login = (req, res) => {
  const { email, password } = req.body;
  // Check if the user exists in the database
  const query = 'SELECT * FROM users WHERE email = ?';
  db.query(query, [email], (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Error fetching user' });
    }

    if (results.length === 0) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }
    // Compare the password with the hashed password
    const user = results[0];
    bcrypt.compare(password, user.password, (err, isMatch) => {
      if (err) {
        return res.status(500).json({ message: 'Error comparing passwords' });
      }
      if (!isMatch) {
        return res.status(400).json({ message: 'Invalid email or password' });
      }
      // Create JWT token
      const token = jwt.sign({ userId: user.id, role: user.role }, 'secretkey', { expiresIn: '1h' });
      // Send token and role as part of the response
      res.status(200).json({
        message: 'Login successful',
        token,
        role: user.role,  // Send the role as part of the response
      });
    });
  });
};
module.exports = { login };
