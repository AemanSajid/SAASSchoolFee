const bcrypt = require('bcryptjs');
const db = require('../config/db'); // Assuming you have a db.js for database configuration

const register = async (req, res) => {
  const { name, email, password, role } = req.body;

  try {
    // Validate input
    if (!name || !email || !password || !role) {
      return res.status(400).json({ message: 'All fields are required.' });
    }

    // Check if user already exists
    const query = 'SELECT * FROM users WHERE email = ?';
    db.query(query, [email], (err, results) => {
      if (err) {
        return res.status(500).json({ message: 'Error checking user' });
      }

      if (results.length > 0) {
        return res.status(400).json({ message: 'User already exists' });
      }

      // Hash the password
      bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) {
          return res.status(500).json({ message: 'Error hashing password' });
        }

        // Insert the new user into the database
        const insertQuery = 'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)';
        db.query(insertQuery, [name, email, hashedPassword, role], (err, results) => {
          if (err) {
            return res.status(500).json({ message: 'Error inserting user' });
          }

          res.status(201).json({ message: 'Registration successful!' });
        });
      });
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error during registration' });
  }
};

module.exports = { register };
