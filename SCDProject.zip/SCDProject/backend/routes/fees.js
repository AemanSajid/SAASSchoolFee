const express = require('express');
const router = express.Router();
const feesController = require('../controllers/fees');

// Route to fetch fee information for a parent
router.get('/fees/:userId', feesController.getFees);

// Route to submit payment and mark fee as 'paid'
router.post('/submit-fee/:userId', feesController.submitFee);

module.exports = router;
