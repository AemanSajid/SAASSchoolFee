const express = require('express');
const cors = require('cors');
const { register } = require('./controllers/register');
const { login } = require('./controllers/login');
const feesRoutes = require('./routes/fees');
const db = require('./config/db'); // Make sure your database connection is correctly imported

const app = express();

// Middleware
app.use(cors());
app.use(express.json()); // For parsing JSON requests

// Registration route
app.post('/api/register', register);

// Login route
app.post('/api/login', login);

//Fee route
app.use('/api/parent', feesRoutes);

// Admin route to get all users with role 'parent'
app.get('/api/admin/parents', (req, res) => {
    const query = 'SELECT id, name, role FROM users WHERE role = "parent"';
    db.query(query, (err, results) => {
        if (err) {
            console.error("Error fetching parents:", err);
            return res.status(500).json({ message: 'Error fetching parents' });
        }
        res.status(200).json(results);
    });
});

// Admin route to get all fee information
app.get('/api/admin/fees', (req, res) => {
    const query = 'SELECT * FROM fees';
    db.query(query, (err, results) => {
        if (err) {
            console.error("Error fetching fees:", err);
            return res.status(500).json({ message: 'Error fetching fees' });
        }
        res.status(200).json(results);
    });
});

// Admin route to add pending fees for a parent
app.post('/api/admin/add-fee', (req, res) => {
    const { userId, amount } = req.body;
    if (!userId || !amount) {
        return res.status(400).json({ message: 'User ID and fee amount are required' });
    }

    const query = 'INSERT INTO fees (user_id, amount, status) VALUES (?, ?, "pending")';
    db.query(query, [userId, amount], (err, results) => {
        if (err) {
            console.error("Error adding fee:", err);
            return res.status(500).json({ message: 'Error adding fee' });
        }
        res.status(201).json({ message: 'Fee added successfully' });
    });
});

// Route to fetch fee info for a specific parent
app.get('/api/parent/fees/:userId', (req, res) => {
  const { userId } = req.params;

  const parentQuery = 'SELECT id, name FROM users WHERE id = ?';
  db.query(parentQuery, [userId], (parentErr, parentResult) => {
      if (parentErr) {
          console.error("Error fetching parent:", parentErr);
          return res.status(500).json({ message: 'Error fetching parent' });
      }

      if (parentResult.length === 0) {
          return res.status(404).json({ message: 'Parent not found' });
      }
      const parentName = parentResult[0].name;

      const feeQuery = `
          SELECT 
              f.amount, 
              f.status
          FROM fees f
          WHERE f.user_id = ?
      `;

      db.query(feeQuery, [userId], (feeErr, feeResult) => {
          if (feeErr) {
              console.error("Error fetching fee data:", feeErr);
              return res.status(500).json({ message: 'Error fetching fee data' });
          }

          if (feeResult.length === 0) {
              return res.status(404).json({ message: 'No fees found for this parent' });
          }
          const feeData = {
              name: parentName,
              fees: feeResult
          };
          res.status(200).json({ fee: feeData });
      });
  });
});

// Parent route to get fee status
app.get('/api/parent/fee-status/:userId', (req, res) => {
  const { userId } = req.params;

  const parentQuery = 'SELECT id from users where id = ? AND role = "parent"';
  db.query(parentQuery, [userId], (parentErr, parentResult) => {
      if (parentErr) {
          console.error("Error fetching parent:", parentErr);
          return res.status(500).json({ message: 'Error fetching parent' });
      }
      if (parentResult.length === 0) {
          return res.status(404).json({ message: 'Parent Not Found' });
      }

      const query = `
          SELECT amount, status
          FROM fees
          WHERE user_id = ? 
          AND status = "pending"
      `;
      db.query(query, [userId], (err, results) => {
          if (err) {
              console.error("Error fetching fee status:", err);
              return res.status(500).json({ message: 'Error fetching fee status' });
          }
          if (results.length === 0) {
              return res.status(404).json({ message: 'No pending fees found for this parent.' });
          }

          res.status(200).json({ fee: results[0] });
      });
  });
});

// Parent route to submit fee payment
app.post('/api/parent/submit-fee/:userId', (req, res) => {
  const { userId } = req.params;
  const { amount } = req.body;

  if (!amount) {
      return res.status(400).json({ message: 'Payment amount is required' });
  }

  const parentQuery = 'SELECT id from users where id = ? AND role = "parent"';
  db.query(parentQuery, [userId], (parentErr, parentResult) => {
      if (parentErr) {
          console.error("Error fetching parent:", parentErr);
          return res.status(500).json({ message: 'Error fetching parent' });
      }
      if (parentResult.length === 0) {
          return res.status(404).json({ message: 'Parent Not Found' });
      }

      const query = 'UPDATE fees SET status = "paid" WHERE user_id = ? AND status = "pending"';
      db.query(query, [userId], (err, results) => {
          if (err) {
              console.error("Error submitting fee:", err);
              return res.status(500).json({ message: 'Error submitting fee' });
          }

          if (results.affectedRows > 0) {
              res.status(200).json({ message: 'Fee paid successfully' });
          } else {
              res.status(404).json({ message: 'No pending fee found to pay' });
          }
      });
  });
});


// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});


// backend/server.js

/*const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json()); // For parsing JSON requests

// Database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Replace with your MySQL username
  password: 'aeman12345', // Replace with your MySQL password
  database: 'user_management',
});

// Check the DB connection
db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});

// Fetch all users
app.get('/api/users', (req, res) => {
  const sql = 'SELECT * FROM users';
  db.query(sql, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// Fetch active users (from view)
app.get('/api/active-users', (req, res) => {
  const sql = 'SELECT * FROM active_users';
  db.query(sql, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// Fetch inactive users (from view)
app.get('/api/inactive-users', (req, res) => {
  const sql = 'SELECT * FROM inactive_users';
  db.query(sql, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

app.post('/api/users', (req, res) => {
    const { name, email, status } = req.body;
    const sql = 'INSERT INTO users (name, email, status) VALUES (?, ?, ?)';
    db.query(sql, [name, email, status], (err, result) => {
      if (err) throw err;
      res.json({ message: 'User added', userId: result.insertId });
    });
  });
  

// Update a user's details
app.put('/api/users/:id', (req, res) => {
  const { id } = req.params;
  const { name, email, status } = req.body; // Status can also be updated
  const sql = 'UPDATE users SET name = ?, email = ?, status = ? WHERE id = ?';
  db.query(sql, [name, email, status, id], (err, result) => {
    if (err) throw err;
    res.json({ message: 'User updated successfully' });
  });
});

// Delete a user
app.delete('/api/users/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM users WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) throw err;
    res.json({ message: 'User deleted successfully' });
  });
});

// Server start
app.listen(5000, () => {
  console.log('Server running on http://localhost:5000');
});
*/