import React from "react";
import { Link, useNavigate } from "react-router-dom";
import logo from "../assets/logo.png"; // Make sure you have the logo image in src/assets/

function Navbar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Clear any auth session if needed
    navigate("/");
  };

  return (
    <nav
      className="navbar navbar-expand-lg px-4"
      style={{
        backgroundColor: "#2f3e46",
        borderBottom: "3px solid #4caf50",
        boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
      }}
    >
      <div className="container-fluid">
        <Link
          to="/"
          className="navbar-brand d-flex align-items-center"
          style={{
            color: "#4caf50",
            fontFamily: "'Fredoka One', cursive",
            fontSize: "24px",
          }}
        >
          <img
            src={logo}
            alt="Logo"
            style={{
              width: "40px",
              height: "40px",
              marginRight: "10px",
            }}
          />
          School Fee SaaS
        </Link>

        {/* Navigation links */}
        <div className="d-flex align-items-center ms-auto gap-4">
          <Link
            to="/register"
            className="nav-link"
            style={{ color: "#eeeeee", fontWeight: "500" }}
          >
            Register
          </Link>

          <Link
            to="/"
            className="nav-link"
            style={{ color: "#eeeeee", fontWeight: "500" }}
          >
            Login
          </Link>

          <Link
            to="/"
            onClick={handleLogout}
            className="nav-link"
            style={{ color: "#eeeeee", fontWeight: "500" }}
          >
            Logout
          </Link>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
