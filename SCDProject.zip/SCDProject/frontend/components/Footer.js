import React from "react";

function Footer() {
  return (
    <footer
      className="text-center text-light py-4 mt-5"
      style={{ backgroundColor: "#2f3e46", borderTop: "3px solid #4caf50" }}
    >
      <div className="mb-3">
        <a
          href="https://instagram.com"
          target="_blank"
          rel="noopener noreferrer"
          className="mx-3 text-success"
        >
          <i className="fab fa-instagram fa-lg"></i>
        </a>
        <a
          href="https://facebook.com"
          target="_blank"
          rel="noopener noreferrer"
          className="mx-3 text-success"
        >
          <i className="fab fa-facebook fa-lg"></i>
        </a>
        <a
          href="https://twitter.com"
          target="_blank"
          rel="noopener noreferrer"
          className="mx-3 text-success"
        >
          <i className="fab fa-twitter fa-lg"></i>
        </a>
      </div>
      <p className="mb-0">© 2025 School Fee SaaS. All rights reserved.</p>
    </footer>
  );
}

export default Footer;
