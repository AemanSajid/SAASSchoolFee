import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "./Pages/Login";
import Register from "./Pages/Register";
import AdminDashboard from "./Pages/AdminDashboard";
import ParentDashboard from "./Pages/ParentDashboard";
import Payment from "./Pages/Payment";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import PaymentPage from "./Pages/Payment"; // <-- import it
import FetchDataHook from './Pages/FetchDataHook';
import ProtectedRoute from "./components/ProtectedRoute";
import authService from "./services/authService";

function App() {
  return (
    <Router>
      <Navbar />
      <div className="container mt-4">
        <Routes>
          <Route path="/payment" element={<PaymentPage />} />
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/parent" element={<ParentDashboard />} />
          <Route path="/payment" element={<Payment />} />
        </Routes>
      </div>
      <Footer />
    </Router>
  );
}

export default App;

