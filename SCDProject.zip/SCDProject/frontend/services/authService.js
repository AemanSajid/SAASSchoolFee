const authService = {
    login: (user) => {
      localStorage.setItem("loggedInUser", JSON.stringify(user));
    },
  
    logout: () => {
      localStorage.removeItem("loggedInUser");
    },
  
    getCurrentUser: () => {
      return JSON.parse(localStorage.getItem("loggedInUser"));
    },
  };
  
  export default authService;
  