import React, { useState } from "react";
import { useFetchData } from "./FetchDataHook";
import { useFeeHandler } from "./FeeHandler";

function AdminDashboard() {
  const [activeSection, setActiveSection] = useState("dashboard");

  // Fetch parents and fees
  const { data: parents, error: parentsError } = useFetchData("http://localhost:5000/api/admin/parents");
  const { data: feeData, error: feeError } = useFetchData("http://localhost:5000/api/admin/fees");

  const { newFee, setNewFee, message, handleAddFee, fees } = useFeeHandler();

  // Update the fees state
  const updatedFees = feeData.reduce((acc, fee) => {
    acc[fee.user_id] = fee;
    return acc;
  }, {});

  const renderSection = () => {
    switch (activeSection) {
      case "dashboard":
        return <div style={styles.section}><h3>Welcome to the Admin Dashboard</h3><p>Manage users and fees here.</p></div>;
      case "fee":
        return (
          <div style={styles.section}>
            <h3>Add New Fee for Parent</h3>
            {message && <p style={{ color: message.includes("successfully") ? "green" : "red" }}>{message}</p>}
            <div>
              <label htmlFor="userId">Parent User ID:</label>
              <input
                type="number"
                id="userId"
                value={newFee.userId}
                onChange={(e) => setNewFee({ ...newFee, userId: e.target.value })}
              />
            </div>
            <div>
              <label htmlFor="amount">Amount:</label>
              <input
                type="number"
                id="amount"
                value={newFee.amount}
                onChange={(e) => setNewFee({ ...newFee, amount: e.target.value })}
              />
            </div>
            <button onClick={handleAddFee}>Add Fee</button>
            <h3 style={{ marginTop: "20px" }}>ADD ABOVE THE FEE OF REGISTERED PARENTS FROM ID.</h3>
          </div>
        );
      case "payments":
        return (
          <div style={styles.section}>
            <h3>Payments</h3>
            <p>Below is the current fee structure:</p>
            <div style={{ marginTop: "20px" }}>
              <h4>Fee Structure</h4>
              <ul>
                <li><strong>Admission Fee:</strong> $1000</li>
                <li><strong>Monthly Tuition Fee:</strong> $500</li>
                <li><strong>Lab Fee (per term):</strong> $300</li>
                <li><strong>Library Fee (yearly):</strong> $150</li>
              </ul>
            </div>
          </div>
        );
      case "analytics":
        return (
          <div style={styles.section}>
            <h3>Reports & Analytics</h3>
            <div style={{ marginTop: "20px" }}>
              <p><strong>Total Students:</strong> 100</p>
              <p><strong>Payments Done:</strong> 75</p>
              <p><strong>Payments Pending:</strong> 25</p>
            </div>
            <div style={{ marginTop: "30px" }}>
              <h4>Payment Status Chart</h4>
              <div style={{
                display: "flex",
                height: "20px",
                width: "300px",
                backgroundColor: "#ddd",
                borderRadius: "10px",
                overflow: "hidden",
                marginTop: "10px"
              }}>
                <div style={{ width: "75%", backgroundColor: "#4caf50" }} />
                <div style={{ width: "25%", backgroundColor: "#f44336" }} />
              </div>
              <div style={{ marginTop: "10px", fontSize: "14px" }}>
                <span style={{ color: "#4caf50", marginRight: "15px" }}>■ Paid</span>
                <span style={{ color: "#f44336" }}>■ Pending</span>
              </div>
            </div>
          </div>
        );
      case "users":
        return (
          <div style={styles.section}>
            <h3>Registered Parents</h3>
            <ul style={styles.list}>
              {parents?.map((parent) => (
                <li key={parent.id} style={{ marginBottom: "20px" }}>
                  <div><strong>{parent.role}</strong> - {parent.name} (ID: {parent.id})</div>
                  {updatedFees[parent.id] ? (
                    <div style={{ marginTop: "10px" }}>
                      <h4>Fee Information</h4>
                      <p>Fee: ${updatedFees[parent.id].amount}</p>
                      <p>Status: {updatedFees[parent.id].status}</p>
                    </div>
                  ) : (
                    <p>No fee information available for this parent.</p>
                  )}
                </li>
              ))}
            </ul>
          </div>
        );
      default:
        return <p style={styles.section}>Select an option from the left panel</p>;
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.sidebar}>
        <h2 style={styles.sidebarTitle}>Admin Panel</h2>
        {["dashboard", "fee", "payments", "analytics", "users"].map((section) => (
          <button
            key={section}
            style={{
              ...styles.sidebarButton,
              backgroundColor: activeSection === section ? "#2e7d32" : "#4caf50",
            }}
            onClick={() => setActiveSection(section)}
          >
            {section.charAt(0).toUpperCase() + section.slice(1)}
          </button>
        ))}
      </div>
      <div style={styles.mainContent}>
        <h2 style={styles.header}>Admin Dashboard</h2>
        {renderSection()}
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: "flex",
    minHeight: "100vh",
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    backgroundColor: "#f1f1f1",
  },
  sidebar: {
    width: "220px",
    backgroundColor: "#2f2f2f",
    padding: "20px",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  sidebarTitle: {
    color: "#fff",
    marginBottom: "15px",
    fontSize: "22px",
  },
  sidebarButton: {
    backgroundColor: "#4caf50",
    border: "none",
    color: "#fff",
    padding: "10px",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "15px",
    transition: "background-color 0.3s",
  },
  mainContent: {
    flex: 1,
    padding: "30px",
    backgroundColor: "#fff",
  },
  header: {
    color: "#2e7d32",
    fontSize: "26px",
    marginBottom: "20px",
  },
  section: {
    backgroundColor: "#e8f5e9",
    padding: "20px",
    borderRadius: "8px",
    boxShadow: "0 2px 5px rgba(0,0,0,0.1)",
  },
  list: {
    listStyle: "disc",
    paddingLeft: "20px",
  },
};

export default AdminDashboard;