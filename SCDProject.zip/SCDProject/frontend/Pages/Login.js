import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { jwtDecode as jwt_decode } from 'jwt-decode';  // Corrected import

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('http://localhost:5000/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessage(data.message || 'Login failed');
        return;
      }
      // If JWT is returned, decode the token
      const decodedToken = jwt_decode(data.token); // Decode the JWT token
      const userRole = data.role || decodedToken.role; // Get the role from the response or token
      console.log('User role:', userRole);  // For debugging purposes
      // Save token and role in localStorage
      localStorage.setItem('token', data.token);
      localStorage.setItem('role', userRole);  // Store the role
      // Navigate based on role
      if (userRole === 'admin') {
        navigate('/admin'); // Redirect to admin dashboard
      } else if (userRole === 'parent') {
        navigate('/parent'); // Redirect to parent dashboard
      } else {
        setMessage('Unknown role');
      }      
      alert('Login successful!');
    } catch (err) {
      setMessage('Something went wrong!');
      console.error(err);
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.heading}>Login</h2>
        <form onSubmit={handleLogin} style={styles.form}>
          <input
            style={styles.input}
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            style={styles.input}
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit" style={styles.button}>Login</button>
        </form>
        {message && <p style={styles.message}>{message}</p>}
      </div>
    </div>
  );
};
const styles = {
  container: {
    backgroundColor: "#1e1e1e",
    color: "#fff",
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  },
  card: {
    backgroundColor: "#2b2b2b",
    padding: "40px",
    borderRadius: "10px",
    boxShadow: "0 8px 20px rgba(0, 255, 0, 0.1)",
    width: "100%",
    maxWidth: "400px",
  },
  heading: {
    marginBottom: "25px",
    fontSize: "28px",
    color: "#4caf50",
    textAlign: "center",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "15px",
  },
  input: {
    padding: "12px",
    border: "1px solid #444",
    borderRadius: "6px",
    backgroundColor: "#3a3a3a",
    color: "#fff",
    fontSize: "16px",
  },
  button: {
    backgroundColor: "#4caf50",
    padding: "12px",
    border: "none",
    borderRadius: "6px",
    color: "#fff",
    fontSize: "16px",
    fontWeight: "bold",
    cursor: "pointer",
    transition: "background-color 0.3s",
  },
  message: {
    marginTop: "15px",
    textAlign: "center",
    color: "#c8e6c9",
    fontWeight: "500",
  },
};

export default Login;
