import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from 'react-router-dom';

function Payment() {
  const navigate = useNavigate(); // ✅ Moved inside here!

  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');

  const handlePayment = async () => {
    try {
      const userId = localStorage.getItem('userId'); // Assuming userId saved on login
      const response = await axios.post('http://localhost:5000/api/payment/pay', {
        userId,
        amount
      });

      setMessage(response.data.message);

      // After payment success, navigate to receipt page
      navigate('/receipt', { state: { receipt: response.data } });

    } catch (error) {
      console.error(error);
      setMessage(error.response?.data?.message || "Payment failed.");
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.heading}>Make Payment</h2>
        <input
          type="number"
          placeholder="Enter Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          style={styles.input}
        />
        <button onClick={handlePayment} style={styles.button}>
          Submit Payment
        </button>
        {message && <p style={styles.text}>{message}</p>}
      </div>
    </div>
  );
}

const styles = {
  container: {
    backgroundColor: "#1e1e1e",
    minHeight: "100vh",
    color: "#fff",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    padding: "20px",
  },
  card: {
    backgroundColor: "#2c2c2c",
    padding: "40px",
    borderRadius: "10px",
    boxShadow: "0 10px 25px rgba(0, 255, 0, 0.1)",
    maxWidth: "500px",
    width: "100%",
    textAlign: "center",
  },
  heading: {
    fontSize: "28px",
    marginBottom: "20px",
    color: "#4caf50",
  },
  input: {
    width: "100%",
    padding: "12px",
    marginBottom: "20px",
    borderRadius: "6px",
    border: "none",
    fontSize: "16px",
  },
  button: {
    backgroundColor: "#4caf50",
    color: "#fff",
    padding: "12px 20px",
    borderRadius: "6px",
    fontWeight: "bold",
    fontSize: "16px",
    cursor: "pointer",
  },
  text: {
    marginTop: "20px",
    color: "#ccc",
  },
};

export default Payment;
