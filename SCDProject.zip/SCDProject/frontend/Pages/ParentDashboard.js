import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ParentDashboard = () => {
  const [activeSection, setActiveSection] = useState('feeInfo');
  const [feeInfo, setFeeInfo] = useState(null);
  const [submitFeeMessage, setSubmitFeeMessage] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [userId] = useState(8); // Hardcoded for now
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchFeeInfo();
  }, [userId]);

  const fetchFeeInfo = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`http://localhost:5000/api/parent/fees/${userId}`);
      setFeeInfo(response.data.fee);
    } catch (error) {
      console.error('Error fetching fee data', error);
      setFeeInfo(null);
    } finally {
      setLoading(false);
    }
  };

  const fetchFeeStatus = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`http://localhost:5000/api/parent/fee-status/${userId}`);
      setFeeInfo(response.data.fee);
    } catch (error) {
      console.error('Error fetching fee status', error);
      setFeeInfo(null);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitFee = async () => {
    if (!paymentAmount || Number(paymentAmount) <= 0) {
      setSubmitFeeMessage('Please enter a valid payment amount.');
      setTimeout(() => setSubmitFeeMessage(''), 3000);
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(`http://localhost:5000/api/parent/submit-fee/${userId}`, { amount: paymentAmount });
      setSubmitFeeMessage(response.data.message || 'Payment submitted successfully!');
      setPaymentAmount('');
      await fetchFeeInfo(); // Refresh fee info after payment
    } catch (error) {
      console.error('Error submitting fee', error);
      setSubmitFeeMessage(error.response?.data?.message || 'Failed to submit fee.');
    } finally {
      setTimeout(() => setSubmitFeeMessage(''), 3000);
      setLoading(false);
    }
  };

  const renderSection = () => {
    if (loading) {
      return <div style={styles.section}>Loading...</div>;
    }

    switch (activeSection) {
      case 'feeInfo':
        return (
          <div style={styles.section}>
            <h3>Fee Information</h3>
            {feeInfo ? (
              <>
                {feeInfo.name && <p>Name: {feeInfo.name}</p>}
                {Array.isArray(feeInfo.fees) && feeInfo.fees.length > 0 ? (
                  <ul>
                    {feeInfo.fees.map((fee, index) => (
                      <li key={index}>
                        Amount: ${fee.amount}, Status: {fee.status}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p>No fees found.</p>
                )}
              </>
            ) : (
              <p>No fee information available.</p>
            )}
          </div>
        );

        case 'feeStatus':
          return (
            <div style={styles.section}>
              <h3>Fee Status</h3>
        
              {feeInfo ? (
                <>
                  <p>Amount: ${feeInfo.amount}</p>
                  <p>Status: {feeInfo.status}</p>
        
                  {/* Hardcoded Fee Structure */}
                  <div style={{ marginTop: "20px" }}>
                    <h4>Fee Structure</h4>
                    <ul>
                      <li><strong>Monthly Fee:</strong> $500</li>
                      <li><strong>Term 1 (Jan-Apr):</strong> $2000</li>
                      <li><strong>Term 2 (May-Aug):</strong> $2000</li>
                      <li><strong>Term 3 (Sep-Dec):</strong> $2000</li>
                    </ul>
                  </div>
                </>
              ) : (
                <p>No fee status available.</p>
              )}
            </div>
          );
        

      case 'submitFee':
        return (
          <div style={styles.section}>
            <h3>Submit Fee</h3>
            {submitFeeMessage && (
              <p style={{ color: submitFeeMessage.toLowerCase().includes('success') ? 'green' : 'red' }}>
                {submitFeeMessage}
              </p>
            )}
            <div>
              <label htmlFor="paymentAmount">Payment Amount:</label>
              <input
                type="number"
                id="paymentAmount"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                style={{ marginLeft: '10px', padding: '5px' }}
              />
            </div>
            <button onClick={handleSubmitFee} style={styles.button}>
              Submit Payment
            </button>
          </div>
        );

      default:
        return <div style={styles.section}>Select an option from the left panel</div>;
    }
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        <h2 style={styles.sidebarTitle}>Parent Panel</h2>
        {['feeInfo', 'feeStatus', 'submitFee'].map((section) => (
          <button
            key={section}
            style={{
              ...styles.sidebarButton,
              backgroundColor: activeSection === section ? '#2e7d32' : '#4caf50',
            }}
            onClick={() => {
              setActiveSection(section);
              if (section === 'feeStatus') fetchFeeStatus();
              if (section === 'feeInfo') fetchFeeInfo();
            }}
          >
            {section.charAt(0).toUpperCase() + section.slice(1).replace(/([A-Z])/g, ' $1').trim()}
          </button>
        ))}
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        <h2 style={styles.header}>Parent Dashboard</h2>
        {renderSection()}
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    minHeight: '100vh',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    backgroundColor: '#f1f1f1',
  },
  sidebar: {
    width: '220px',
    backgroundColor: '#2f2f2f',
    padding: '20px',
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
  },
  sidebarTitle: {
    color: '#fff',
    marginBottom: '15px',
    fontSize: '22px',
  },
  sidebarButton: {
    backgroundColor: '#4caf50',
    border: 'none',
    color: '#fff',
    padding: '10px',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '15px',
    transition: 'background-color 0.3s',
  },
  mainContent: {
    flex: 1,
    padding: '30px',
    backgroundColor: '#fff',
  },
  header: {
    color: '#2e7d32',
    fontSize: '26px',
    marginBottom: '20px',
  },
  section: {
    backgroundColor: '#e8f5e9',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
  },
  button: {
    marginTop: '10px',
    padding: '8px 16px',
    backgroundColor: '#2e7d32',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '15px',
  },
};

export default ParentDashboard;
