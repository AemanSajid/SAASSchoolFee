import { useState } from "react";
import axios from "axios";

export const useFeeHandler = () => {
  const [newFee, setNewFee] = useState({ userId: "", amount: "" });
  const [message, setMessage] = useState("");
  const [fees, setFees] = useState({});

  const handleAddFee = async () => {
    try {
      const response = await axios.post("http://localhost:5000/api/admin/add-fee", newFee);
      setMessage(response.data.message);
      const feeResponse = await axios.get("http://localhost:5000/api/admin/fees");
      const updatedFees = feeResponse.data.reduce((acc, fee) => {
        acc[fee.user_id] = fee;
        return acc;
      }, {});
      setFees(updatedFees);
      setNewFee({ userId: "", amount: "" });
      setTimeout(() => setMessage(""), 3000);
    } catch (error) {
      setMessage(error.response?.data?.message || "Failed to add fee.");
      setTimeout(() => setMessage(""), 3000);
    }
  };

  return { newFee, setNewFee, message, handleAddFee, fees };
};
